
package com.libraryarc;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class LibraryInventory extends javax.swing.JFrame {

    private JList<String> bookList;
    private DefaultListModel<String> bookListModel;
    private JTextField titleField;
    private JTextField qtyField;
    private JTextField deleteField;
    private JButton addButton;
    private JButton okButton;

    private final String FILE_NAME = "books.txt"; // File name for storing books

    public LibraryInventory() {
        initComponents();
        loadFromFile(); // Load books from file when the application starts
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel();
        JPanel leftPanel = new JPanel();
        JPanel rightPanel = new JPanel();
        JScrollPane listScrollPane = new JScrollPane();
        JScrollPane titleScrollPane = new JScrollPane();
        JScrollPane qtyScrollPane = new JScrollPane();
        JScrollPane deleteScrollPane = new JScrollPane();

        bookListModel = new DefaultListModel<>();
        bookList = new JList<>(bookListModel);
        titleField = new JTextField();
        qtyField = new JTextField();
        deleteField = new JTextField();
        addButton = new JButton("ADD");
        okButton = new JButton("OK");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        mainPanel.setLayout(new BorderLayout());
        mainPanel.setPreferredSize(new Dimension(700, 570));

        leftPanel.setLayout(new BorderLayout());
        leftPanel.setPreferredSize(new Dimension(200, 570)); // Adjusted size

        bookList.setModel(new AbstractListModel<String>() {
            String[] strings = { "Book 1", "Book 2", "Book 3", "Book 4", "Book 5" };

            public int getSize() {
                return strings.length;
            }

            public String getElementAt(int i) {
                return strings[i];
            }
        });
        listScrollPane.setViewportView(bookList);
        leftPanel.add(listScrollPane, BorderLayout.CENTER);

        mainPanel.add(leftPanel, BorderLayout.WEST);

        rightPanel.setLayout(new GridLayout(4, 2, 5, 5));
        rightPanel.setPreferredSize(new Dimension(500, 570)); // Adjusted size

        JLabel titleLabel = new JLabel("Title");
        rightPanel.add(titleLabel);
        titleScrollPane.setViewportView(titleField);
        rightPanel.add(titleField);

        JLabel qtyLabel = new JLabel("Qty.");
        rightPanel.add(qtyLabel);
        qtyScrollPane.setViewportView(qtyField);
        rightPanel.add(qtyField);

        JLabel deleteLabel = new JLabel("Delete");
        rightPanel.add(deleteLabel);
        deleteScrollPane.setViewportView(deleteField);
        rightPanel.add(deleteField);

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });
        rightPanel.add(addButton);

        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                okButtonActionPerformed(evt);
            }
        });
        rightPanel.add(okButton);

        mainPanel.add(rightPanel, BorderLayout.CENTER);

        getContentPane().add(mainPanel);

        pack();
    }

    private void addButtonActionPerformed(ActionEvent evt) {
        String title = titleField.getText();
        String qty = qtyField.getText();

        if (!title.isEmpty() && !qty.isEmpty()) {
            String bookEntry = "Title: " + title + ", Qty: " + qty;
            bookListModel.addElement(bookEntry);

            // Append the new book to the file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
                writer.write(bookEntry);
                writer.newLine();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error writing to file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }

            titleField.setText("");
            qtyField.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Please enter both title and quantity.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void okButtonActionPerformed(ActionEvent evt) {
        String deleteTitle = deleteField.getText();

        if (!deleteTitle.isEmpty()) {
            List<String> updatedBooks = new ArrayList<>();
            boolean found = false;

            // Read all existing books from the list model
            for (int i = 0; i < bookListModel.getSize(); i++) {
                String element = bookListModel.getElementAt(i);
                if (element.contains(deleteTitle)) {
                    found = true;
                } else {
                    updatedBooks.add(element);
                }
            }

            if (found) {
                bookListModel.clear();

                // Update the list model with the updated books
                for (String book : updatedBooks) {
                    bookListModel.addElement(book);
                }

                // Update the file with the updated book list
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
                    for (String book : updatedBooks) {
                        writer.write(book);
                        writer.newLine();
                    }
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(this, "Error writing to file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Book title not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }

            deleteField.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Please enter the title to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (int i = 0; i < bookListModel.getSize(); i++) {
                String book = bookListModel.getElementAt(i);
                writer.write(book);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving to file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadFromFile() {
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            return; // No file to load if it doesn't exist yet
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                bookListModel.addElement(line);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading from file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LibraryInventory().setVisible(true);
            }
        });
    }
}