package com.libraryarc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class LibraryAccountGUI extends JFrame {

    // Components
    private JLabel titleLabel;
    private JTable booksTable;

    public LibraryAccountGUI() {
        setTitle("Library Account Inventory");
        setSize(1280, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Initialize components
        titleLabel = new JLabel("Library Account Inventory");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(JLabel.CENTER);

        // Table setup
        String[] columnNames = {"Book Title", "Author", "Year", "Genre"};
        Object[][] data = {
                {"The Gift of the MagiC", "O. Henry", "1905", "Short Story"},
                {"Rebecca", " Daphne du Maurier", "1938", "Mystery"},
                {"Harry Potter", "J. K. Rowling", "1997", "Fantasy"},
                {" ", " ", " ", " "},
                {" ", " ", " ", " "}
        };

        // Create a DefaultTableModel with data and column names
        DefaultTableModel tableModel = new DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Allow editing for Author (column 1) and Year (column 2) columns
                return column == 1 || column == 2;
            }
        };

        booksTable = new JTable(tableModel);
        booksTable.setFont(new Font("Arial", Font.PLAIN, 16));
        booksTable.setRowHeight(30);
        JScrollPane tableScrollPane = new JScrollPane(booksTable);

        // Layout manager: BorderLayout for main content pane
        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel topPanel = new JPanel(new BorderLayout());

        // Adding components to top panel
        topPanel.add(titleLabel, BorderLayout.NORTH);

        // Adding components to main panel
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(tableScrollPane, BorderLayout.CENTER);

        // Set main panel to content pane
        setContentPane(mainPanel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                LibraryAccountGUI gui = new LibraryAccountGUI();
                gui.setVisible(true);
            }
        });
    }
}