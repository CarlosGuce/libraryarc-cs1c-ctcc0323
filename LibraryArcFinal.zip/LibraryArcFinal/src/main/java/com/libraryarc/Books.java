package com.libraryarc;

import com.libraryarc.LoginFrame;

/**
 *
 * @author namra
 */
public class Books {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
         public void run() {
                LoginFrame Library = new LoginFrame();
                Library.setVisible(true);
                Library.pack();
                Library.setLocationRelativeTo(null);
              }
        });
    }
}